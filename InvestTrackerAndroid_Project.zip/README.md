# INVEST TRACKER Android

Aplikasi Android offline berbasis Kotlin + WebView dengan dashboard Dark Premium.

## Build APK
1. Install Android Studio (versi terbaru yang mendukung Android Gradle Plugin 8.7.3).
2. Ekstrak ZIP ini.
3. Buka folder `InvestTrackerAndroid` melalui Android Studio.
4. Tunggu Gradle Sync dan izinkan Android Studio mengunduh Android SDK 35 serta Gradle/plugin yang diperlukan.
5. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. APK debug akan berada di `app/build/outputs/apk/debug/app-debug.apk`.

## Fitur
- Dashboard nilai portofolio, modal, untung/rugi.
- Alokasi BTC 35%, VRT 25%, KO 20%, RDPU 20%.
- Setoran bulanan fleksibel; default Rp3.500.000.
- Catat pembelian, harga beli dan unit.
- Input harga pasar manual dan kalkulasi nilai saat ini.
- Grafik akumulasi modal, laporan bulanan, CSV dan backup/restore JSON.
- Data disimpan lokal pada WebView melalui localStorage.

## Catatan
- Harga pasar belum terhubung ke API Pluang/exchange; input manual.
- Untuk VRT dan KO, masukkan harga per unit dalam rupiah (konversi dari USD memakai kurs transaksi Anda).
- Data tersimpan di perangkat. Simpan backup JSON berkala.
- Perhitungan untung/rugi belum menghitung pajak/biaya jual yang belum dimasukkan. Masukkan biaya beli ke nominal modal transaksi jika ingin memasukkannya dalam basis modal.
